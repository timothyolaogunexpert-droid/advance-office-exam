# CONFIDENTIAL — Advance Office Administrator Marking Guide

Do not publish this file in the public website folder.

## Objective answers (50 marks)

1. B — Guide marketing activities
2. C — Conversion rate
3. A — Grouping similar customers
4. D — Brand awareness
5. B — Click-through rate
6. B — Managing Facebook and Instagram
7. C — Organizing publications
8. D — 4%
9. B — Tutorial video
10. C — Acknowledge the concern
11. A — Encourage a response
12. C — Appropriate business access
13. B — Views without paid distribution
14. C — Location targeting
15. A — Watch time
16. A — Hook → Build-up → Reveal → CTA
17. D — Weak suspense development
18. C — Supports brand recognition
19. A — 10%
20. B — Weaker visual recognition
21. B — Target reader audience
22. C — Mystery teaser
23. A — Advance Reader Copy
24. D — Reader-to-buyer journey
25. B — Generate launch excitement
26. C — Historical fiction readers
27. A — A free incentive for readers
28. D — Business management tools
29. B — Parents and educators
30. A — It offers business insights and management features
31. A — Connect the books through storytelling
32. D — A genuine reader review
33. B — Character discussion prompts
34. C — A hook and clear action
35. A — Countdown and teaser content
36. C — Shaping business identity and perception
37. B — Expand character-focused content
38. C — Live Q&A session
39. B — Brand identity
40. D — It supports audience familiarity
41. B — Build interest in the book
42. C — Planned scenes and sequence
43. A — Opening hook
44. D — Emotional tone
45. B — Emotional character scenes
46. C — Control the story's rhythm
47. A — Character consistency
48. D — 9:16
49. B — Preserve reader curiosity
50. C — Book title and call to action

## Short answers (20 marks)

Accept equivalent accurate wording. Each is worth 1 mark.

51. Reach is unique accounts; impressions are total displays.
52. Any two: audience, objectives, platforms, resources, content pillars.
53. Poor targeting, weak CTA, or irrelevant content.
54. A recurring theme, plus a valid example.
55. Organic is unpaid; paid involves advertising spend.
56. A relevant sales metric with valid reasoning.
57. Review current performance and identify improvements.
58. Verify and understand the complaint.
59. Any two: polls, questions, useful posts, community replies.
60. To create relevant content for intended customers.
61. Any two: teaser, cover reveal, countdown, excerpt, character introduction.
62. Build credibility and support buying decisions.
63. Author promotion builds writer identity; book promotion markets a title.
64. Reading-order posts, recaps, or linked character content.
65. Adults often purchase books for young children.
66. Visual plan of trailer scenes and sequence.
67. Any two: hook, striking visuals, tension, engaging sound.
68. Use consistent references, prompts, and character details.
69. Establish mood, tension, and emotional impact.
70. Any two: review synopsis, plan concept, clarify requirements, plan scenes.

## Practical rubric (30 marks)

71: Problems (2), content ideas (2), relevant metric and explanation (2).

72: Three pre-launch ideas (3), engagement strategy (2), metric (1).

73: Opening hook (2), coherent scenes (2), suspenseful ending and promotion (2).

74: Engagement rate 720/18000 = 4% (2), purchase conversion 12/240 = 5% (2), justified improvement (2).

75: Three relevant client details (3), workable plan (2), progress reporting (1).

## Revision notes

Replaced original objective questions 6, 12, 16, 17, 18, 20, 28, 30, 36 and 39 with questions on Meta Business Suite, trailer structure, business logos, Facebook Pages and branding. Original 75 questions / 100 marks / 60 minutes retained.
