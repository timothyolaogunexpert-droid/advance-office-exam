export const QUESTIONS = [
  {
    "id": "M1",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "What is the primary purpose of a social media strategy?",
    "options": [
      "Increase posting frequency",
      "Guide marketing activities",
      "Improve graphic quality",
      "Reduce content expenses"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M2",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "A clothing brand gets many likes but very few sales. Which metric should it examine first?",
    "options": [
      "Follower growth",
      "Profile impressions",
      "Conversion rate",
      "Posting frequency"
    ],
    "correct": 2,
    "marks": 1
  },
  {
    "id": "M3",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "What does audience segmentation involve?",
    "options": [
      "Grouping similar customers",
      "Scheduling different posts",
      "Selecting brand colors",
      "Comparing platform features"
    ],
    "correct": 0,
    "marks": 1
  },
  {
    "id": "M4",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "A business wants more people to recognize its brand. Which objective fits best?",
    "options": [
      "Lead generation",
      "Customer retention",
      "Website conversion",
      "Brand awareness"
    ],
    "correct": 3,
    "marks": 1
  },
  {
    "id": "M5",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "Which metric measures the percentage of people who clicked a link after seeing it?",
    "options": [
      "Engagement rate",
      "Click-through rate",
      "Audience retention",
      "Conversion value"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M6",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "What is one major function of Meta Business Suite?",
    "options": [
      "Creating websites",
      "Managing Facebook and Instagram",
      "Editing cinematic videos",
      "Designing company logos"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M7",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "What is a content calendar mainly used for?",
    "options": [
      "Measuring revenue",
      "Managing followers",
      "Organizing publications",
      "Creating advertisements"
    ],
    "correct": 2,
    "marks": 1
  },
  {
    "id": "M8",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "A post reaches 5,000 people and gets 200 interactions. What is its engagement rate by reach?",
    "options": [
      "2%",
      "5%",
      "10%",
      "4%"
    ],
    "correct": 3,
    "marks": 1
  },
  {
    "id": "M9",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "Which content type is most suitable for demonstrating how a product works?",
    "options": [
      "Customer quote",
      "Tutorial video",
      "Company logo",
      "Event announcement"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M10",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "A brand receives negative comments about delivery delays. What should the manager do first?",
    "options": [
      "Delete all comments",
      "Disable comment access",
      "Acknowledge the concern",
      "Publish another promotion"
    ],
    "correct": 2,
    "marks": 1
  },
  {
    "id": "M11",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "What is the main role of a call to action?",
    "options": [
      "Encourage a response",
      "Explain brand history",
      "Increase caption length",
      "Improve image quality"
    ],
    "correct": 0,
    "marks": 1
  },
  {
    "id": "M12",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "A client wants you to manage their Facebook and Instagram pages without sharing their personal password. What should they provide?",
    "options": [
      "Their personal login",
      "Their recovery email",
      "Appropriate business access",
      "Their account password"
    ],
    "correct": 2,
    "marks": 1
  },
  {
    "id": "M13",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "What does organic reach mean?",
    "options": [
      "Views from paid promotions",
      "Views without paid distribution",
      "Visits from email campaigns",
      "Clicks from sponsored posts"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M14",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "A restaurant wants to attract customers living nearby. Which targeting method is most relevant?",
    "options": [
      "Interest targeting",
      "Device targeting",
      "Location targeting",
      "Language targeting"
    ],
    "correct": 2,
    "marks": 1
  },
  {
    "id": "M15",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "Which metric is most useful for evaluating how long viewers watch a video?",
    "options": [
      "Watch time",
      "Follower count",
      "Profile visits",
      "Link clicks"
    ],
    "correct": 0,
    "marks": 1
  },
  {
    "id": "M16",
    "type": "mcq",
    "subject": "Book Trailer Creation",
    "prompt": "Which sequence best represents a basic promotional book trailer structure?",
    "options": [
      "Hook → Build-up → Reveal → CTA",
      "CTA → Reveal → Hook → Build-up",
      "Reveal → CTA → Build-up → Hook",
      "Build-up → CTA → Hook → Reveal"
    ],
    "correct": 0,
    "marks": 1
  },
  {
    "id": "M17",
    "type": "mcq",
    "subject": "Book Trailer Creation",
    "prompt": "A 30-second book trailer reveals the entire plot within the first 10 seconds. What is the main problem?",
    "options": [
      "Incorrect video format",
      "Poor audio quality",
      "Excessive visual effects",
      "Weak suspense development"
    ],
    "correct": 3,
    "marks": 1
  },
  {
    "id": "M18",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "What is one major benefit of having a recognizable business logo?",
    "options": [
      "Guarantees more sales",
      "Eliminates advertising costs",
      "Supports brand recognition",
      "Replaces marketing strategy"
    ],
    "correct": 2,
    "marks": 1
  },
  {
    "id": "M19",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "A campaign generates 120 leads, but only 12 become customers. What is the lead-to-customer conversion rate?",
    "options": [
      "10%",
      "12%",
      "20%",
      "15%"
    ],
    "correct": 0,
    "marks": 1
  },
  {
    "id": "M20",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "A company uses different logos across its social media pages, website, and promotional materials. What is the likely consequence?",
    "options": [
      "Stronger brand consistency",
      "Weaker visual recognition",
      "Higher organic engagement",
      "Better audience targeting"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M21",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "What should an author identify before creating a book marketing campaign?",
    "options": [
      "Preferred font styles",
      "Target reader audience",
      "Daily posting limits",
      "Trailer export settings"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M22",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "An author is launching a thriller novel. Which post is most likely to build curiosity?",
    "options": [
      "Office working hours",
      "Publishing invoice",
      "Mystery teaser",
      "Author's equipment list"
    ],
    "correct": 2,
    "marks": 1
  },
  {
    "id": "M23",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "What is an ARC in book marketing?",
    "options": [
      "Advance Reader Copy",
      "Author Review Campaign",
      "Audience Reach Calculation",
      "Approved Reading Contract"
    ],
    "correct": 0,
    "marks": 1
  },
  {
    "id": "M24",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "An author has many followers but very few book purchases. What should be examined first?",
    "options": [
      "Profile theme",
      "Posting software",
      "Hashtag count",
      "Reader-to-buyer journey"
    ],
    "correct": 3,
    "marks": 1
  },
  {
    "id": "M25",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "What is the purpose of a book cover reveal?",
    "options": [
      "Announce printing costs",
      "Generate launch excitement",
      "Explain publishing contracts",
      "Introduce editing software"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M26",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "An author writes historical fiction. Which audience is most relevant?",
    "options": [
      "General business owners",
      "Graphic design students",
      "Historical fiction readers",
      "Technology product buyers"
    ],
    "correct": 2,
    "marks": 1
  },
  {
    "id": "M27",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "What is a reader magnet?",
    "options": [
      "A free incentive for readers",
      "A paid advertising platform",
      "A book printing service",
      "A publishing analytics tool"
    ],
    "correct": 0,
    "marks": 1
  },
  {
    "id": "M28",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "Which feature is generally available to Facebook business Pages but not standard personal profiles in the same way?",
    "options": [
      "Personal friend requests",
      "Private photo albums",
      "Individual profile timelines",
      "Business management tools"
    ],
    "correct": 3,
    "marks": 1
  },
  {
    "id": "M29",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "A children's book author wants to reach people who purchase books for young children. Which audience is most relevant?",
    "options": [
      "Corporate investors",
      "Parents and educators",
      "Software developers",
      "University researchers"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M30",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "A client uses only a personal Facebook profile to promote their business. Why might a Facebook Page be more suitable?",
    "options": [
      "It offers business insights and management features",
      "It automatically increases customer purchases",
      "It removes the need for promotional content",
      "It guarantees visibility to all followers"
    ],
    "correct": 0,
    "marks": 1
  },
  {
    "id": "M31",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "An author has three published books in one series. What is a useful promotional approach?",
    "options": [
      "Connect the books through storytelling",
      "Promote each book without context",
      "Hide the earlier book covers",
      "Avoid mentioning recurring characters"
    ],
    "correct": 0,
    "marks": 1
  },
  {
    "id": "M32",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "Which post is an example of social proof for a book?",
    "options": [
      "An author's writing schedule",
      "A publishing company logo",
      "A list of chapter titles",
      "A genuine reader review"
    ],
    "correct": 3,
    "marks": 1
  },
  {
    "id": "M33",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "A fantasy author wants readers to discuss the story. Which content is most suitable?",
    "options": [
      "Printing specifications",
      "Character discussion prompts",
      "Advertising account settings",
      "Publisher contact details"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M34",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "What should a book promotional caption usually include?",
    "options": [
      "Only the purchase link",
      "Only the book's price",
      "A hook and clear action",
      "A long author biography"
    ],
    "correct": 2,
    "marks": 1
  },
  {
    "id": "M35",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "An author wants to promote a book before its release. Which approach is most appropriate?",
    "options": [
      "Countdown and teaser content",
      "Post-launch sales reports",
      "Final royalty statements",
      "Outdated reader statistics"
    ],
    "correct": 0,
    "marks": 1
  },
  {
    "id": "M36",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "What does branding involve?",
    "options": [
      "Only creating a business logo",
      "Only choosing company colors",
      "Shaping business identity and perception",
      "Posting advertisements every day"
    ],
    "correct": 2,
    "marks": 1
  },
  {
    "id": "M37",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "An author notices that character-focused posts outperform generic promotions. What should the manager do?",
    "options": [
      "Stop all book promotion",
      "Expand character-focused content",
      "Remove all previous posts",
      "Change the book's title"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M38",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "Which platform feature can help an author interact directly with readers?",
    "options": [
      "Account verification",
      "Image compression",
      "Live Q&A session",
      "Automated file backup"
    ],
    "correct": 2,
    "marks": 1
  },
  {
    "id": "M39",
    "type": "mcq",
    "subject": "Social Media Marketing",
    "prompt": "Two businesses sell similar products, but one is recognized for its friendly communication, consistent visuals, and customer experience. What does this demonstrate?",
    "options": [
      "Audience segmentation",
      "Brand identity",
      "Content scheduling",
      "Paid advertising"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M40",
    "type": "mcq",
    "subject": "Author Social Media Marketing",
    "prompt": "Why is consistency important in author marketing?",
    "options": [
      "It guarantees bestseller status",
      "It replaces paid advertising",
      "It eliminates audience research",
      "It supports audience familiarity"
    ],
    "correct": 3,
    "marks": 1
  },
  {
    "id": "M41",
    "type": "mcq",
    "subject": "Book Trailer Creation",
    "prompt": "What is the primary purpose of a book trailer?",
    "options": [
      "Explain every chapter",
      "Build interest in the book",
      "Replace the written synopsis",
      "Display the publisher's details"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M42",
    "type": "mcq",
    "subject": "Book Trailer Creation",
    "prompt": "What should a book trailer storyboard contain?",
    "options": [
      "Advertising payment records",
      "Reader email addresses",
      "Planned scenes and sequence",
      "Publishing contract details"
    ],
    "correct": 2,
    "marks": 1
  },
  {
    "id": "M43",
    "type": "mcq",
    "subject": "Book Trailer Creation",
    "prompt": "A thriller trailer begins with a long author introduction. What should be improved?",
    "options": [
      "Opening hook",
      "Video dimensions",
      "Export filename",
      "End-screen logo"
    ],
    "correct": 0,
    "marks": 1
  },
  {
    "id": "M44",
    "type": "mcq",
    "subject": "Book Trailer Creation",
    "prompt": "Which element is most important when selecting music for a suspense trailer?",
    "options": [
      "Artist popularity",
      "File size",
      "Release year",
      "Emotional tone"
    ],
    "correct": 3,
    "marks": 1
  },
  {
    "id": "M45",
    "type": "mcq",
    "subject": "Book Trailer Creation",
    "prompt": "A client wants a cinematic trailer for a romance novel. Which visual approach is most suitable?",
    "options": [
      "Technical diagrams",
      "Emotional character scenes",
      "Financial charts",
      "Product demonstrations"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M46",
    "type": "mcq",
    "subject": "Book Trailer Creation",
    "prompt": "What is the role of pacing in video editing?",
    "options": [
      "Increase file resolution",
      "Set the upload destination",
      "Control the story's rhythm",
      "Choose the book's price"
    ],
    "correct": 2,
    "marks": 1
  },
  {
    "id": "M47",
    "type": "mcq",
    "subject": "Book Trailer Creation",
    "prompt": "An AI-generated character changes appearance between scenes. What should be improved?",
    "options": [
      "Character consistency",
      "Caption punctuation",
      "Posting frequency",
      "Video description"
    ],
    "correct": 0,
    "marks": 1
  },
  {
    "id": "M48",
    "type": "mcq",
    "subject": "Book Trailer Creation",
    "prompt": "What is a common aspect ratio for Instagram Reels?",
    "options": [
      "4:3",
      "16:9",
      "1:1",
      "9:16"
    ],
    "correct": 3,
    "marks": 1
  },
  {
    "id": "M49",
    "type": "mcq",
    "subject": "Book Trailer Creation",
    "prompt": "What is the best reason to avoid revealing the entire ending in a book trailer?",
    "options": [
      "Reduce editing costs",
      "Preserve reader curiosity",
      "Shorten the author's biography",
      "Increase the video resolution"
    ],
    "correct": 1,
    "marks": 1
  },
  {
    "id": "M50",
    "type": "mcq",
    "subject": "Book Trailer Creation",
    "prompt": "What should appear near the end of a promotional book trailer?",
    "options": [
      "Editing software settings",
      "Complete production credits",
      "Book title and call to action",
      "Every chapter's summary"
    ],
    "correct": 2,
    "marks": 1
  },
  {
    "id": "S1",
    "type": "short",
    "subject": "Social Media Marketing",
    "prompt": "Explain the difference between social media reach and impressions.",
    "marks": 1
  },
  {
    "id": "S2",
    "type": "short",
    "subject": "Social Media Marketing",
    "prompt": "Mention two factors you would consider before creating a social media content calendar for a new client.",
    "marks": 1
  },
  {
    "id": "S3",
    "type": "short",
    "subject": "Social Media Marketing",
    "prompt": "A client complains that their posts receive likes but no inquiries. Mention one possible reason.",
    "marks": 1
  },
  {
    "id": "S4",
    "type": "short",
    "subject": "Social Media Marketing",
    "prompt": "What is a content pillar? Give one example.",
    "marks": 1
  },
  {
    "id": "S5",
    "type": "short",
    "subject": "Social Media Marketing",
    "prompt": "Explain one difference between organic marketing and paid advertising.",
    "marks": 1
  },
  {
    "id": "S6",
    "type": "short",
    "subject": "Social Media Marketing",
    "prompt": "A business owner wants to increase sales through Instagram. Mention one metric you would monitor and explain why.",
    "marks": 1
  },
  {
    "id": "S7",
    "type": "short",
    "subject": "Social Media Marketing",
    "prompt": "What is the purpose of a social media audit?",
    "marks": 1
  },
  {
    "id": "S8",
    "type": "short",
    "subject": "Social Media Marketing",
    "prompt": "A client receives an angry comment from a customer. What should you do before responding?",
    "marks": 1
  },
  {
    "id": "S9",
    "type": "short",
    "subject": "Social Media Marketing",
    "prompt": "Mention two ways to encourage audience engagement without running paid advertisements.",
    "marks": 1
  },
  {
    "id": "S10",
    "type": "short",
    "subject": "Social Media Marketing",
    "prompt": "Why should a social media manager understand a client's target audience before creating content?",
    "marks": 1
  },
  {
    "id": "S11",
    "type": "short",
    "subject": "Author Social Media Marketing",
    "prompt": "An author is preparing to launch a new book. Mention two types of content you would recommend before the launch.",
    "marks": 1
  },
  {
    "id": "S12",
    "type": "short",
    "subject": "Author Social Media Marketing",
    "prompt": "Explain why genuine reader reviews are useful in book promotion.",
    "marks": 1
  },
  {
    "id": "S13",
    "type": "short",
    "subject": "Author Social Media Marketing",
    "prompt": "What is the difference between promoting an author and promoting a particular book?",
    "marks": 1
  },
  {
    "id": "S14",
    "type": "short",
    "subject": "Author Social Media Marketing",
    "prompt": "An author has published several books in one series. Mention one way to encourage readers to explore the entire series.",
    "marks": 1
  },
  {
    "id": "S15",
    "type": "short",
    "subject": "Author Social Media Marketing",
    "prompt": "Why might a children's book author target parents and teachers rather than children directly?",
    "marks": 1
  },
  {
    "id": "S16",
    "type": "short",
    "subject": "Book Trailer Creation",
    "prompt": "What is a book trailer storyboard, and why is it needed?",
    "marks": 1
  },
  {
    "id": "S17",
    "type": "short",
    "subject": "Book Trailer Creation",
    "prompt": "Mention two elements that can make the first five seconds of a book trailer engaging.",
    "marks": 1
  },
  {
    "id": "S18",
    "type": "short",
    "subject": "Book Trailer Creation",
    "prompt": "An AI-generated book trailer shows the same character with different faces across scenes. How would you address this?",
    "marks": 1
  },
  {
    "id": "S19",
    "type": "short",
    "subject": "Book Trailer Creation",
    "prompt": "Why is sound design important in a cinematic book trailer?",
    "marks": 1
  },
  {
    "id": "S20",
    "type": "short",
    "subject": "Book Trailer Creation",
    "prompt": "A client wants a 60-second trailer for a book but provides only the book cover and synopsis. Mention two things you would do before beginning production.",
    "marks": 1
  },
  {
    "id": "P1",
    "type": "practical",
    "subject": "Social Media Marketing",
    "prompt": "A skincare business has 850 Instagram followers. The owner posts product pictures almost every day, but engagement is low and very few customers make inquiries. You've just been hired as the social media manager. (1) Identify two possible problems with the current approach (2 marks). (2) Suggest two content ideas that could attract potential customers (2 marks). (3) Explain one way you would measure whether your new strategy is working (2 marks).",
    "marks": 6
  },
  {
    "id": "P2",
    "type": "practical",
    "subject": "Author Social Media Marketing",
    "prompt": "An author is releasing a new fantasy novel in three weeks. Their Instagram account has 300 followers, and they have been posting only book cover pictures. The author wants to attract more readers before launch day. (1) Suggest three different content ideas for the pre-launch campaign (3 marks). (2) Explain how you would encourage readers to interact with the content (2 marks). (3) Recommend one metric to track the campaign's performance (1 mark).",
    "marks": 6
  },
  {
    "id": "P3",
    "type": "practical",
    "subject": "Book Trailer Creation",
    "prompt": "A client hires you to create a 30-second cinematic trailer for a mystery novel. The story follows a young journalist who receives an anonymous letter directing her to an abandoned mansion. Inside, she discovers a secret that could change her life. (1) Describe how you would open the trailer to capture attention (2 marks). (2) Describe two scenes you would include in the trailer (2 marks). (3) Explain how you would end the trailer without revealing the story's secret (2 marks).",
    "marks": 6
  },
  {
    "id": "P4",
    "type": "practical",
    "subject": "Social Media Marketing",
    "prompt": "You've managed an author's social media for one month. The report shows 18,000 accounts reached, 720 interactions, 240 link clicks, and 12 book purchases. (1) Calculate the engagement rate based on reach (2 marks). (2) Calculate the conversion rate from link clicks to book purchases (2 marks). (3) Suggest one action that could improve book purchases next month, and explain why (2 marks).",
    "marks": 6
  },
  {
    "id": "P5",
    "type": "practical",
    "subject": "Social Media Marketing",
    "prompt": "A new author hires you to manage Instagram, Facebook, and TikTok while also producing a cinematic book trailer. The author wants to begin posting immediately but has not provided a clear target audience, brand direction, or complete book information. (1) Mention three important pieces of information you would request before starting (3 marks). (2) Explain how you would organize the social media work and trailer production (2 marks). (3) Describe one way you would keep the client informed about progress (1 mark).",
    "marks": 6
  }
];
export const publicQuestion=q=>({id:q.id,type:q.type,subject:q.subject,prompt:q.prompt,options:q.options,marks:q.marks});
