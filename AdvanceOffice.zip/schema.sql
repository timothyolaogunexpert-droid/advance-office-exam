-- Run once in Supabase SQL Editor. Never expose the service role key to browsers.
create table if not exists public.attempts (
 id uuid primary key default gen_random_uuid(),
 student_name text not null check(length(student_name) between 2 and 120),
 student_email text not null,
 student_id text not null,
 token_hash text not null,
 started_at timestamptz not null default now(),
 deadline_at timestamptz not null default (now() + interval '60 minutes'),
 last_seen timestamptz not null default now(),
 finished_at timestamptz,
 status text not null default 'active' check(status in ('active','submitted','auto_submitted','expired')),
 warning_count integer not null default 0,
 answers jsonb not null default '{}'::jsonb,
 question_order jsonb not null default '[]'::jsonb,
 objective_score numeric(6,2),
 manual_score numeric(6,2),
 grades jsonb not null default '{}'::jsonb,
 final_score numeric(6,2),
 email_status text,
 unique(student_email),
 unique(student_id)
);
create table if not exists public.events (
 id bigint generated always as identity primary key,
 attempt_id uuid not null references public.attempts(id) on delete cascade,
 kind text not null,
 details jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);
create index if not exists attempts_monitor_idx on public.attempts(status,last_seen);
create index if not exists events_attempt_idx on public.events(attempt_id,created_at);
alter table public.attempts enable row level security;
alter table public.events enable row level security;
-- No browser-facing RLS policies: all access goes through protected server functions.
